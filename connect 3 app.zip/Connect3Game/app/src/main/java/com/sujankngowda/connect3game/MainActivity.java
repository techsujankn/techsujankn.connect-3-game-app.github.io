package com.sujankngowda.connect3game;

import androidx.appcompat.app.AppCompatActivity;
import androidx.gridlayout.widget.GridLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int activePlayer=1;
    //0=yellow, 1=red, 2=empty
    int[] gameState={2,2,2,2,2,2,2,2,2};
    boolean gameOver=true;
    int[][] winningPositions={{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
    public void dropin(View view){
        ImageView counter=(ImageView) view;

        int tappedCounter=Integer.parseInt(counter.getTag().toString());


            if(gameState[tappedCounter]==2&&gameOver) {
            gameState[tappedCounter] = activePlayer;
            counter.setTranslationY(-1500);

            if (activePlayer == 1) {
                counter.setImageResource(R.drawable.yellow);
                activePlayer = 0;
            } else {
                counter.setImageResource(R.drawable.red);
                activePlayer = 1;
            }

            counter.animate().translationYBy(1500).setDuration(400);
            for (int[] winningPosition : winningPositions) {
                if ((gameState[winningPosition[0]] == gameState[winningPosition[1]]) && (gameState[winningPosition[1]] == gameState[winningPosition[2]]) && (gameState[winningPosition[0]] != 2)) {
                    //someone has won
                    gameOver = false;
                    String winner = "";
                    if (activePlayer == 0) {
                        winner = "yellow";
                    } else {
                        winner = "red";
                    }

                    Button winnerButton = (Button) findViewById(R.id.button);
                    TextView winnerText = (TextView) findViewById(R.id.winnerView);
                    winnerText.setText(winner + "\thas won!");
                    winnerButton.setVisibility(View.VISIBLE);
                    winnerText.setVisibility(View.VISIBLE);
                }
            }
            int i=0;
            while(i<gameState.length){
                if(gameState[i]==0||gameState[i]==1){
                    i++;
                }
                else
                    break;

            }
            if (i==gameState.length){
                Button winnerButton = (Button) findViewById(R.id.button);
                TextView winnerText = (TextView) findViewById(R.id.winnerView);
                winnerText.setText("Draw match!");
                winnerButton.setVisibility(View.VISIBLE);
                winnerText.setVisibility(View.VISIBLE);
            }

            }



    }
        public  void playAgain(View view){
            Button winnerButton=(Button)findViewById(R.id.button);
            TextView winnerText=(TextView)findViewById(R.id.winnerView);
                winnerButton.setVisibility(View.INVISIBLE);
                winnerText.setVisibility(View.INVISIBLE);
          GridLayout gridLayout=(GridLayout)findViewById(R.id.gridLayout);
            for (int i = 0; i < gridLayout.getChildCount(); i++) {
                ImageView counter = (ImageView) gridLayout.getChildAt(i);
                counter.setImageDrawable(null);
            }

            activePlayer = 1;
        //0=yellow, 1=red, 2=empty
                for (int i = 0; i < gameState.length; i++) {
            gameState[i] = 2;
        }
    gameOver = true;
}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
